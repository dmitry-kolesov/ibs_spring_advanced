package com.luxoft.springadvanced.springbootadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootadminApplicationTests {

	@Test
	void contextLoads() {
	}

}
