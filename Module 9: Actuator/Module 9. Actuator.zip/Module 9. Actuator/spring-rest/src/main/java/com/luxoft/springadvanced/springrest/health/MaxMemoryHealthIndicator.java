package com.luxoft.springadvanced.springrest.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Service;

@Service("someMyOwnIndicator")
public class MaxMemoryHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        long maxMemory = Runtime.getRuntime().maxMemory();
        long neededMemory = 10 * 1024 * 1024L;
        boolean invalid = maxMemory < neededMemory;
        Status status = invalid ? Status.DOWN : Status.UP;
        return Health.status(status).withDetail("amount",maxMemory).build();
    }
}
