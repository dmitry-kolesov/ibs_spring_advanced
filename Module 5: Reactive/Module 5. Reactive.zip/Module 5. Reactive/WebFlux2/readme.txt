Docker command to create Rabbit MQ queue

docker run -d --hostname my-rabbit --name sample-rabbit -p 15672:15672 -p 5671:5671 -p 5672:5672 rabbitmq:3-management

Create a queue with the name person-event-queue

URLs:
http://localhost:8080/persons
http://localhost:8080/persons/{id}/cities
http://localhost:8080/persons/cities

See travel.rest to see the results
(you should run requests in browser because IDEA rest client
does not support data streaming).