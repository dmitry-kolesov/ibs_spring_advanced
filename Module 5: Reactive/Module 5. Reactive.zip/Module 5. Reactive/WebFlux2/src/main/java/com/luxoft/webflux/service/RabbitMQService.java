package com.luxoft.webflux.service;

import com.luxoft.webflux.model.PersonEvent;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RabbitMQService {
	
	private final RabbitTemplate rabbitTemplate;
	
	@Value("${person.event.queue.name}")
	private String MESSAGE_QUEUE;

	public RabbitMQService(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
	}

	public void sendMessage(PersonEvent personEvent) {
		log.info("Sending message to queue: " + personEvent);
		rabbitTemplate.convertAndSend(MESSAGE_QUEUE, personEvent);
	}



}
