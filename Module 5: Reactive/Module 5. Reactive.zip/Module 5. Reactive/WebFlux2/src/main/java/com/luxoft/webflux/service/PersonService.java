package com.luxoft.webflux.service;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import com.luxoft.webflux.model.Person;
import com.luxoft.webflux.model.PersonEvent;
import org.springframework.stereotype.Service;

import com.luxoft.webflux.repository.PersonRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class PersonService {

	private final PersonRepository personRepository;
	private final RabbitMQService rabbitMQService;
	private Random rnd = new Random();

	public PersonService(RabbitMQService rabbitMQService, PersonRepository personRepository) {
		this.rabbitMQService = rabbitMQService;
		this.personRepository = personRepository;
	}

	AtomicInteger counter = new AtomicInteger();
	// generates a new travel every 10 seconds, and sends it to RabbitMQ
	public Flux<PersonEvent> cities(String personId) {
		return Flux.<PersonEvent>generate(
			sink -> {
				String[] cities = { "Moscow",
						"Kiev", "Bucharest",
						"Sofia", "Krakow" };
				String city = cities[rnd.nextInt(cities.length)]
						+counter.getAndIncrement();
				PersonEvent personEvent =
						new PersonEvent(personId, city, new Date());
				publishEvent(personEvent);
				sink.next(personEvent);
				sleep(10000);
			}).share();
	}

	private void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public Mono<Person> getPersonById(String id) {
		return personRepository.findById(id);
	}

	public Flux<Person> getAllPersons() {
		return personRepository.findAll();
	}
	
	private void publishEvent(PersonEvent personEvent) {
		rabbitMQService.sendMessage(personEvent);
	}

}