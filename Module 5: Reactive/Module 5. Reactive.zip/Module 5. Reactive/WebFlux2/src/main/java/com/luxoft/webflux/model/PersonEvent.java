package com.luxoft.webflux.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PersonEvent implements Serializable {
	private String personId;
	private String city;
	private Date date;
}