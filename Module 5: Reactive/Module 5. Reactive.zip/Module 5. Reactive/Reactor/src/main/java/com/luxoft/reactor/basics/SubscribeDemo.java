package com.luxoft.reactor.basics;

import reactor.core.Disposable;
import reactor.core.publisher.Flux;

public class SubscribeDemo {

    public static void main(String[] args) {

        Flux<String> locations =
                Flux.just("Bucharest", "Krakow", "Moscow", "Kiev",
                        "Sofia");
        Disposable disposable = locations
                .doOnNext(s -> System.out.println(s))
                .map(String::length)
                .filter(l -> l >= 5)
                .take(2)
                .subscribe(l -> System.out.println("Length: " + l),
                        Throwable::printStackTrace,
                        () -> System.out.println("Done."));
        disposable.dispose();



    }
}
