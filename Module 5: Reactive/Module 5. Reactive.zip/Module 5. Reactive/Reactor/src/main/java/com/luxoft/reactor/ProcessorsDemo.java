package com.luxoft.reactor;

import reactor.core.publisher.*;
import reactor.core.scheduler.Schedulers;
import org.junit.Test;

import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProcessorsDemo {

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testDirectProcessor() {
        // DirectProcessor can have multiple consumers,
        // and supports multiple producers.
        // However, all producers must produce messages
        // on the same Thread.
        // In terms of interaction model, DirectProcessor
        // only supports PUSH from the
        // source through the processor to the Subscribers
//        DirectProcessor<Long> data = DirectProcessor.create();
        // replace by EmitterProcessor which is honoring backpressure
         EmitterProcessor<Long> data = EmitterProcessor.create();
        data
                .publishOn(Schedulers.parallel())
                .subscribe(t -> {
                    sleep(1);
                    //System.out.println(t);
                },
                e -> e.printStackTrace(),
                () -> System.out.println("Finished 1"));

        ExecutorService executorService = Executors.newCachedThreadPool();
        executorService.submit(()-> {
            for (long i=0; i<1000000; i++) data.onNext(i);
        });
        executorService.submit(()-> {
            for (long i=0; i<1000000; i++) data.onNext(i);
        });

        sleep(10000);
    }

    @Test
    public void testProcessorComplete() {
        // Once the Direct (or Emitter) Processor has terminated
        // (usually through its sink’s error(Throwable) or
        // complete() methods being called), it lets more
        // subscribers subscribe but replays
        // the termination signal to them immediately.
        //DirectProcessor<Long> data = DirectProcessor.create();
        EmitterProcessor<Long> data = EmitterProcessor.create();
        data.subscribe(t -> System.out.println(t),
                e -> e.printStackTrace(),
                () -> System.out.println("Finished 1"));
        data.onNext(10L);
        //data.onComplete();
        data.subscribe(t -> System.out.println(t),
                e -> e.printStackTrace(),
                () -> System.out.println("Finished 2"));

        data.onNext(12L);

        data.subscribe(t -> System.out.println(t),
                e -> e.printStackTrace(),
                () -> System.out.println("Finished 3"));
        data.onComplete();
    }

    @Test
    public void testReplayProcessor() {
        ReplayProcessor<Integer> data = ReplayProcessor.create(2);
        data.subscribe(t -> System.out.println("subscriber1: "+t));
        FluxSink<Integer> sink = data.sink();
        sink.next(1);
        sink.next(2);
        sink.next(3);
        sink.next(4);
        sink.next(5);
        data.subscribe(t -> System.out.println("subscriber2: "+t));
    }

    @Test
    public void testReplayProcessorCacheLast() {
        ReplayProcessor<Integer> data = ReplayProcessor.cacheLast();
        data.subscribe(t -> System.out.println("subscriber1: "+t));
        FluxSink<Integer> sink = data.sink();
        sink.next(1);
        sink.next(2);
        sink.next(3);
        sink.next(4);
        sink.next(5);
        data.subscribe(t -> System.out.println("subscriber2: "+t));
    }

    @Test
    public void testSinks() {
//        The Sinks categories are:
//
//        many().multicast(): a sink that will transmit only newly pushed data to its subscribers,
//        honoring their backpressure (newly pushed as in "after the subscriber’s subscription").
//
//        many().unicast(): same as above, with the twist that data pushed before the first subscriber registers is buffered.
//
//        many().replay(): a sink that will replay a specified history size of pushed data to new subscribers then
//        continue pushing new data live.
//
//        one(): a sink that will play a single element to its subscribers
//
//        empty(): a sink that will play a terminal signal only to its subscribers (error or complete),
//        but can still be viewed as a Mono<T> (notice the generic type <T>).

        Sinks.Many<Integer> sink = Sinks.unsafe().many().multicast().onBackpressureBuffer(100);
        sink.emitNext(1, Sinks.EmitFailureHandler.FAIL_FAST);
        sink.emitNext(2, Sinks.EmitFailureHandler.busyLooping(Duration.ofSeconds(10)));

        sink.asFlux().parallel(2).runOn(Schedulers.parallel());
        sink.asFlux().subscribe(i -> System.out.println("S1: value:" + i ));
        sink.asFlux().subscribe(i -> {
            try {
                Thread.sleep(5_000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("S2: value:" + i );
        });

        System.out.println("Subscribers count: " + sink.currentSubscriberCount());

        sink.tryEmitNext(10).orThrowWithCause(new IllegalStateException("Can't emmit value 10"));
        sink.emitNext(20, Sinks.EmitFailureHandler.FAIL_FAST);

        Sinks.EmitResult result = sink.tryEmitComplete();
        System.out.println("Completed with status: " + result.isSuccess());

    }
}
