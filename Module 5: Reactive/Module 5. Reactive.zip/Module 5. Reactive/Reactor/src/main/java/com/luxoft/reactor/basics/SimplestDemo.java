package com.luxoft.reactor.basics;

import reactor.core.Disposable;
import reactor.core.publisher.Flux;

import java.time.Duration;

public class SimplestDemo {
    public static void main(String[] args) throws InterruptedException {
        /*Flux<String> locations =
            Flux.just("Bucharest",
                    "Krakow", "Moscow",
                    "Kiev", "Sofia"); //declaration
        locations
                .map(s -> s.length())
                .subscribe(System.out::println);*/
        Flux<String> steps =
//                Flux<Long> steps =
                Flux.interval(Duration.ofSeconds(2))
                        .map(i-> (new String[] {"Bucharest",
                                "Krakow", "Moscow",
                                "Kiev", "Sofia"})[Math.toIntExact(i)])
                .take(5);

        Thread.sleep(5000);

        Disposable disposable = steps.subscribe(l ->
                System.out.println(l));

        Thread.sleep(10000);
        steps
                .map(String::toUpperCase)
                .subscribe(l ->
                System.out.println("Another subscriber: " + l));

        Thread.sleep(10000);
    }
}
