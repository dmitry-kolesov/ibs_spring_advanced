package com.luxoft.reactor.basics;

import reactor.core.Disposable;
import reactor.core.publisher.ConnectableFlux;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicInteger;

public class FluxCreateDemo {
    public static void main(String[] args) throws Exception {
        Flux<String> locations = Flux.create(location -> {
            System.out.println("Starting flux filling in ..");
            String prefix = "created in " + Thread.currentThread().getName() + ": ";

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            location.next(prefix + "Bucharest");
            location.next(prefix + "Krakow");
            location.error(new RuntimeException("Moscow"));
            /*try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }*/
            location.next(prefix + "Kiev");
            location.next(prefix + "Sofia");
            location.complete();
            System.out.println("flux filling in completed.");

        });

        ConnectableFlux<String> connLocations = locations.publish();
        connLocations.subscribe(
                s -> System.out.println("S1: Location: " + s),
                e -> System.out.println("Processed in " + Thread.currentThread().getName() + ": Error: " + e),
                () -> System.out.println("Processed in " + Thread.currentThread().getName() + ": I'm completed"));
        connLocations.subscribe(s -> System.out.println("S2: Location: " + s));
        connLocations.connect();

        /*Disposable d = locations.subscribe(
                s -> System.out.println("Processed in " + Thread.currentThread().getName() + ": Location: " + s),
                e -> System.out.println("Processed in " + Thread.currentThread().getName() + ": Error: " + e),
                () -> System.out.println("Processed in " + Thread.currentThread().getName() + ": I'm completed"));

        Disposable d2 = locations.subscribe(s -> System.out.println("Location of s2: " + s));*/


        /*Flux.generate(
                AtomicInteger::new,
                (item, square) -> {
                    int i = item.getAndIncrement();
                    square.next(i * i);
                    if (i == 10) square.complete();
                    return item;
                }
        ).subscribe(System.out::println);*/


        Thread.sleep(10000);

        /*d.dispose();
        d2.dispose();*/

//        locations.subscribe(s -> System.out.println("Location of s3: " + s));
//        Thread.sleep(10000);


    }




}
