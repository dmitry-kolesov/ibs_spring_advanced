package com.luxoft.reactor;

import org.junit.Test;
import reactor.core.publisher.EmitterProcessor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.test.StepVerifier;
import reactor.test.publisher.TestPublisher;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;

public class TestDemo {

    @Test
    public void testMonoException() {
        Mono<String> monoException =
                Mono.error(new RuntimeException("exception"));
        StepVerifier.create(monoException)
                .expectErrorMessage("exception")
                .verify();
    }



    private EmitterProcessor<Map.Entry<String, String>> processor = null;
    private Mono<String> mono = null;
    private Map<Map.Entry<String, String>, Mono<String>> monoMap = new ConcurrentHashMap<>();


    private void setMono(Map.Entry<String, String> key, Mono<String> newMono) {
        monoMap.put(key, newMono);
    }

    private EmitterProcessor<Map.Entry<String, String>> getProcessor() {
        if (processor == null) {
            processor = EmitterProcessor.create();
            processor.publishOn(Schedulers.boundedElastic())
                .subscribe(
                    pair -> {
                        System.out.println(Thread.currentThread().getName() + ": received token remote request");

                        setMono(
                                pair,
                                Mono.fromFuture(
                                        CompletableFuture.supplyAsync(() -> {

                                            System.out.println(Thread.currentThread().getName() + ": obtaining token");
                                            try {
                                                Thread.sleep(2000);
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                            }
                                            System.out.println(Thread.currentThread().getName() + ": done.");
                                            return  Thread.currentThread().getName() + ": access token for " + pair.getKey();
                                        })
                                ));
                        System.out.println(Thread.currentThread().getName() + ": Mono has been added.");
                    }
            );
        }
        return processor;
    }

    private AtomicInteger cnt = new AtomicInteger(0);
    private Mono<String> getMono(Map.Entry<String, String> user) {

        if (!monoMap.containsKey(user) || cnt.incrementAndGet() > 5) {
                getProcessor().onNext(user);
                cnt.set(0);
            }
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {

        }

        Mono<String> result = monoMap.get(user);
        System.out.println(Thread.currentThread().getName() + ": Mono from map: " + result);
        return result;
//        if (mono == null) {
//            mono = Mono.delay(Duration.ofSeconds(5)).map(l -> "message-" + System.currentTimeMillis());
//        }
//        return mono;
    }

    @Test
    public void testMono() throws Exception {

        Map.Entry<String, String> user1 = new AbstractMap.SimpleEntry("User1", "Password1");
        Map.Entry<String, String> user2 = new AbstractMap.SimpleEntry("User2", "Password2");

        ExecutorService service = Executors.newFixedThreadPool(10);
        for (int i = 0; i < 5; i++) {
            Map.Entry<String, String> usr;
            if (i % 2 == 0) {
                usr = user1;
            } else {
                usr = user2;
            }
            service.submit(() -> {
                System.out.println(Thread.currentThread().getName() + ": acquiring token for user " + usr.getKey());
                Mono t = getMono(usr);
                System.out.println(Thread.currentThread().getName() + ": received token for user " + usr.getKey() + " :" + t.block());
            });
        }

        Thread.sleep(20000);

    }


    @Test
    public void testMonoValue() {
        Mono<String> message =
                Mono.just("message");
        StepVerifier.create(message)
                .expectNext("message")
                .verifyComplete();
    }

    @Test
    public void testStepVerifier() {
        Flux<Integer> flux = Flux.just(1, 2, 3);
        StepVerifier.create(flux)
                .expectNext(1)
                .expectNext(2)
                .expectNext(3)
                .expectComplete()
                .verify(Duration.ofSeconds(10));
    }

    @Test
    public void testPublisher() {
        TestPublisher<Object> publisher =
                TestPublisher.create();
        Flux<Object> stringFlux = publisher.flux();
        List list = new ArrayList();
        stringFlux.subscribe(
                next -> list.add(next),
                ex -> ex.printStackTrace());
        publisher.emit("one", "two");
        assertEquals(2, list.size());
        assertEquals("one", list.get(0));
        assertEquals("two", list.get(1));
    }

}
