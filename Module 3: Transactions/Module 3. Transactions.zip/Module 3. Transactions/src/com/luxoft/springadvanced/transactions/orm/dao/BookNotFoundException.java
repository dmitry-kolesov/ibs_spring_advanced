package com.luxoft.springadvanced.transactions.orm.dao;

public class BookNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
}
