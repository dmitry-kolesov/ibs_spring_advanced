package com.luxoft.springadvanced.transactions.data.repositories.version;

import com.luxoft.springadvanced.transactions.orm.model.VersionedBook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.TimeUnit;

public class VersionedBookManager {

    @Autowired
    private VersionedBookDao versionedBookDao;

    @Transactional(timeout = 10, propagation = Propagation.REQUIRES_NEW)
    public VersionedBook updateBookWithLock(Integer id, String title, int operationTimeSec) {
        System.out.println(Thread.currentThread().getName() + " - updateBookWithLock: trying to read book...");

        //VersionedBook book = versionedBookDao.findWithOptimisticLockById(id);
        VersionedBook book = versionedBookDao.findWithPessimisticWriteLockById(id);
        //VersionedBook book = versionedBookDao.findWithPessimisticReadLockById(id);


        System.out.println(Thread.currentThread().getName() + " - updateBookWithLock: read book is [" + book + "] " + book.hashCode());
        pause(operationTimeSec);
        book.setTitle(title);

        System.out.println(Thread.currentThread().getName() + " - updateBookWithLock: saving changes ...");
        book = versionedBookDao.save(book);
        System.out.println(Thread.currentThread().getName() + " - done.");
        System.out.println(Thread.currentThread().getName() + " - updateBookWithLock: committing transaction ...");
        return book;
    }

    @Transactional
    public VersionedBook readBook(Integer id) {
        return versionedBookDao.findWithOptimisticLockById(id);
    }

    @Transactional
    public VersionedBook readBookWithLockAndPause(Integer id, int pauseSec) {
        System.out.println(Thread.currentThread().getName() + " - readBookWithLockAndPause: trying to read book...");
        //VersionedBook book = versionedBookDao.findWithPessimisticReadLockById(id);
        //VersionedBook book = versionedBookDao.findWithPessimisticWriteLockById(id);
        VersionedBook book = versionedBookDao.findWithOptimisticLockById(id);
        System.out.println(Thread.currentThread().getName() + " - readBookWithLockAndPause: read book is [" + book + "] " + book.hashCode());
        pause(pauseSec);
        System.out.println(Thread.currentThread().getName() + " - readBookWithLockAndPause: committing transaction ...");
        return book;
    }

    @Transactional
    public VersionedBook readBookAndPause(Integer id, int pauseSec) {
        System.out.println(Thread.currentThread().getName() + " - readBookAndPause: trying to read book...");
        VersionedBook book = versionedBookDao.findOne(id);
        System.out.println(Thread.currentThread().getName() + " - readBookAndPause: read book is [" + book + "] " + book.hashCode());
        pause(pauseSec);
        System.out.println(Thread.currentThread().getName() + " - readBookAndPause: committing transaction ...");
        return book;
    }

    @Transactional
    public void deleteBook(Integer id) {
        System.out.println(Thread.currentThread().getName() + " - deleteBook: trying to read book...");
        //VersionedBook book = versionedBookDao.findWithPessimisticReadLockById(id);
        VersionedBook book = versionedBookDao.findWithPessimisticWriteLockById(id);
        System.out.println(Thread.currentThread().getName() + " - deleteBook: read book is [" + book + "] " + book.hashCode());

        System.out.println(Thread.currentThread().getName() + " - deleteBook: trying to delete book...");
        versionedBookDao.delete(id);
        System.out.println(Thread.currentThread().getName() + " - done.");
        System.out.println(Thread.currentThread().getName() + " - deleteBook: committing transaction ...");
    }


    private void pause(int sec) {
        try {
            Thread.sleep(TimeUnit.SECONDS.toMillis(sec));
        } catch (Exception e) {}
    }
}
