package com.luxoft.springadvanced.transactions.data.repositories;

import com.luxoft.springadvanced.transactions.orm.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.time.LocalDate;

public class BookController {
    @Autowired
    private BookService bookService;

    @Autowired
    private BookDao bookDao;

    @Transactional(noRollbackFor = BookService.SomeException.class)
    public void testLogicalTransaction() {

        printLastBook();
        bookDao.addBook("Spring", Date.valueOf(LocalDate.of(2016, 3, 1)));
        //try {
            bookService.transactionWithException();
            // inside transaction we get an exception,
            // and it is marking exception for rollback-only:
            // setRollbackOnly(true)
        //} catch (BookService.SomeException e) {
       // }
        System.out.println("****** Here we proceed...");
        Book b = bookDao.getLatestBook();
        b.setTitle("Updated");
        bookDao.saveAndFlush(b);
    }

    public void printLastBook() {
        bookService.printLastBook();
    }
}
