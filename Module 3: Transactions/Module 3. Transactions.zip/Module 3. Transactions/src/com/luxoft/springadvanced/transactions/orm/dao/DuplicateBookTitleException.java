package com.luxoft.springadvanced.transactions.orm.dao;

public class DuplicateBookTitleException extends RuntimeException {

	public DuplicateBookTitleException(String message) {
		super(message);
	}
	
	
}
