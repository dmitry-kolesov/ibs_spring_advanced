package com.luxoft.springadvanced.transactions;

import com.luxoft.springadvanced.transactions.data.repositories.BookDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class TransactionEmulator {

    @Autowired
    private BookDao bookDao;

    public void runTest() {
        runInTransaction();
    }

    @Transactional
    protected void runInTransaction() {
        bookDao.checkTitleDuplicate("title");
    }

    public BookDao getBookDao() {
        return bookDao;
    }

    public void setBookDao(BookDao bookDao) {
        this.bookDao = bookDao;
    }
}
