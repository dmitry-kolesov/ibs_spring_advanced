package com.luxoft.springadvanced.transactions.data.repositories.version;

import com.luxoft.springadvanced.transactions.orm.model.VersionedBook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

import javax.persistence.LockModeType;

public interface VersionedBookDao extends JpaRepository<VersionedBook, Integer> {

    @Lock(LockModeType.OPTIMISTIC)
    VersionedBook findWithOptimisticLockById(Integer id);

    @Lock(LockModeType.PESSIMISTIC_READ)
    VersionedBook findWithPessimisticReadLockById(Integer id);

    //@Lock(LockModeType.PESSIMISTIC_FORCE_INCREMENT)
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    VersionedBook findWithPessimisticWriteLockById(Integer id);


}
