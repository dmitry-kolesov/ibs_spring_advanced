package com.luxoft.springadvanced.transactions;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.sql.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.luxoft.springadvanced.transactions.data.repositories.BookController;
import com.luxoft.springadvanced.transactions.data.repositories.BookDao;
import com.luxoft.springadvanced.transactions.data.repositories.BookService;
import com.luxoft.springadvanced.transactions.data.repositories.LogDao;
import com.luxoft.springadvanced.transactions.data.repositories.version.VersionedBookDao;
import com.luxoft.springadvanced.transactions.data.repositories.version.VersionedBookManager;
import com.luxoft.springadvanced.transactions.orm.dao.DuplicateBookTitleException;
import com.luxoft.springadvanced.transactions.orm.model.VersionedBook;
import org.junit.Before;
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Illustrates various transaction propagation attributes.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:application-context.xml"})
public class TransactionPropagationTest {

	@Autowired
	BookController bookController;


	@Autowired
	VersionedBookDao versionedBookDao;

	@Autowired
	private VersionedBookManager versionedBookManager;


	@Autowired
	private BookDao bookDao;

	@Autowired
	private LogDao logDao;

	@Before
	public void clean() {
		bookDao.deleteAll();
		logDao.deleteAll();
	}
	
	@Test
	public void notSupported() {
		// executing in transaction:
		// addLogs is starting transaction, but addSeparateLogsNotSupported() suspends it
		try {
			bookDao.addLogs();
		} catch (Exception e) {}
		
		// no transaction - first record is added in the log even after exception
		logDao.showLogs();		
	}
	
	@Test
	public void supports() {
		// executing without transaction:
		// addSeparateLogsSupports is working with no transaction
		try {
			//logDao.addSeparateLogsSupports();
			logDao.addSeparateLogsSupportsWithTransaction();
		} catch (Exception e) {}

		// no transaction - first record is added in the log even after exception
		logDao.showLogs();
	}

	@Test
	public void mandatory() {
		// get exception because checkTitleDuplicate can be executed only in transaction
		try {
			bookDao.checkTitleDuplicate("Java");
		} catch(Exception e) {
			System.out.println("ERROR! "+e.getMessage());
		}
	}
	
	@Test
	public void never() {
		bookDao.addBook("Java", Date.valueOf(LocalDate.of(2015, 5, 1)));
		// it's safe to call showLogs from no transaction
		logDao.showLogs();
		
		// but prohibited to execute from transaction
		try {
			bookDao.showLogs();
		} catch(Exception e) {
			System.out.println("ERROR! "+e.getMessage());
		}
	}
	
	@Test
	public void requiresNew() {
		// requires new - log message is persisted in the logs even after exception
		// because it was added in the separate transaction
		System.out.println("---------------------------");

		bookDao.addBook("Java", Date.valueOf(LocalDate.of(2015, 5, 1)));
		bookDao.addBook("Spring", Date.valueOf(LocalDate.of(2016, 3, 1)));
		bookDao.addBook("Spring Data", Date.valueOf(LocalDate.of(2016, 1, 1)));

		try {
			bookDao.addBook("Spring", Date.valueOf(LocalDate.of(2016, 3, 1)));
		} catch (DuplicateBookTitleException e) {
			System.out.println("WARN: " + e.getMessage());
		}

		System.out.println("Logs: ");
		logDao.findAll().forEach(System.out::println);
		
		System.out.println("List of added books: ");
		bookDao.findAll().forEach(System.out::println);
	}

	@Test
	public void noRollback() {
		// no rollback - log message is persisted in the logs even after exception
		// because transaction was not rolled back
		bookDao.addBookNoRollback("Java", Date.valueOf(LocalDate.of(2015, 5, 1)));
		bookDao.addBookNoRollback("Spring", Date.valueOf(LocalDate.of(2016, 3, 1)));
		bookDao.addBookNoRollback("Spring Data", Date.valueOf(LocalDate.of(2016, 1, 1)));
		
		try {
			bookDao.addBookNoRollback("Spring", Date.valueOf(LocalDate.of(2016, 3, 1)));
		} catch (DuplicateBookTitleException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("Logs: ");
		logDao.findAll().forEach(System.out::println);
		
		System.out.println("List of added books: ");
		bookDao.findAll().forEach(System.out::println);
	}

	public void addBook() {
		System.out.println("+++++++++++++++++++++++++++");
		VersionedBook book = new VersionedBook();
		book.setTitle("New Book");
		System.out.println(Thread.currentThread().getName() + " - addBook: Book to save: [" + book + "]");
		book = versionedBookDao.save(book);
		System.out.println(Thread.currentThread().getName() + " - addBook: Saved Book: [" + versionedBookManager.readBook(book.getId()) + "]");
		System.out.println("---------------------------");
	}

	public void updateBook(Integer id, String newTitle, int operationTimeSec) {
		System.out.println("+++++++++++++++++++++++++++");
		try {
			versionedBookManager.updateBookWithLock(id, newTitle, operationTimeSec);
			System.out.println(Thread.currentThread().getName() + " - successfully committed.");
		} catch (RuntimeException e) {
			System.out.println(Thread.currentThread().getName() + " - runtime exception was caught, rollback was done.");
			System.out.println(Thread.currentThread().getName() + " - " + e.getClass().getSimpleName() + ": " + e.getMessage());
		} finally {
			System.out.println(Thread.currentThread().getName() + " - current book version [" + versionedBookManager.readBook(1) + "]");
			System.out.println("---------------------------");
		}
	}

	public void deleteBook(Integer id) {
		System.out.println("+++++++++++++++++++++++++++");
		try {
			versionedBookManager.deleteBook(id);
			System.out.println(Thread.currentThread().getName() + " - successfully committed.");
		} catch (RuntimeException e) {
			System.out.println(Thread.currentThread().getName() + " - runtime exception was caught, rollback was done.");
			System.out.println(Thread.currentThread().getName() + " - " + e.getClass().getSimpleName() + ": " + e.getMessage());
		} finally {
			System.out.println(Thread.currentThread().getName() + " - current book version [" + versionedBookManager.readBook(1) + "]");
			System.out.println("---------------------------");
		}
	}

	public void readBookWithLockAnPause(Integer id) {
		System.out.println("+++++++++++++++++++++++++++");
		try {
			versionedBookManager.readBookWithLockAndPause(id, 5);
			System.out.println(Thread.currentThread().getName() + " - successfully committed.");
		} catch (RuntimeException e) {
			System.out.println(Thread.currentThread().getName() + " - runtime exception was caught, rollback was done.");
			System.out.println(Thread.currentThread().getName() + " - " + e.getClass().getSimpleName() + ": " + e.getMessage());
		} finally {
			System.out.println("---------------------------");
		}
	}

	public void readBookAnPause(Integer id) {
		System.out.println("+++++++++++++++++++++++++++");
		try {
			versionedBookManager.readBookAndPause(id, 5);
			System.out.println(Thread.currentThread().getName() + " - successfully committed.");
		} catch (RuntimeException e) {
			System.out.println(Thread.currentThread().getName() + " - runtime exception was caught, rollback was done.");
			System.out.println(Thread.currentThread().getName() + " - " + e.getClass().getSimpleName() + ": " + e.getMessage());
		} finally {
			System.out.println("---------------------------");
		}
	}

	@Test
	public void testVersion() throws Exception {

		addBook();

		updateBook(1, "First-time updated title", 1);
		updateBook(1, "Second-time updated title", 1);

		ExecutorService executorService = Executors.newFixedThreadPool(2);
		executorService.submit(() -> updateBook(1, "Third-time updated title", 5));
		Thread.sleep(200);
		executorService.submit(() -> updateBook(1, "Fourth-time updated title", 1));

		executorService.shutdown();
		executorService.awaitTermination(15, TimeUnit.SECONDS);
	}

	@Test
	public void testLocks() throws Exception {

		addBook();

		ExecutorService executorService = Executors.newFixedThreadPool(5);
		executorService.submit(() -> readBookAnPause(1));
		Thread.sleep(200);
		executorService.submit(() -> readBookWithLockAnPause(1));
		Thread.sleep(200);
		executorService.submit(() -> readBookWithLockAnPause(1));
		Thread.sleep(200);
		executorService.submit(() -> readBookAnPause(1));
		Thread.sleep(200);
		executorService.submit(() -> deleteBook(1));

		executorService.shutdown();
		executorService.awaitTermination(30, TimeUnit.SECONDS);
	}

	@Test
	public void testLogicalTransaction() {
		//try {
			bookController.testLogicalTransaction();
		//} catch (Exception e) {}
		bookController.printLastBook();
	}
}
