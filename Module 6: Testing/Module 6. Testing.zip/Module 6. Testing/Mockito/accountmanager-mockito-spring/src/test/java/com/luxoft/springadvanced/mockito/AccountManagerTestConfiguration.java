package com.luxoft.springadvanced.mockito;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AccountManagerTestConfiguration {

    @Bean
    public AccountManager accountManager() {
        return Mockito.mock(AccountManager.class);
    }

}
