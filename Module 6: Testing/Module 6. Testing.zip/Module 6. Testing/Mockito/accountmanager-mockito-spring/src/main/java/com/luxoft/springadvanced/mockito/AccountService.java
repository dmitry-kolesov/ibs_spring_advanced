package com.luxoft.springadvanced.mockito;

public class AccountService {

    private AccountManager accountManager;

    public void setAccountManager(AccountManager manager) {
        this.accountManager = manager;
    }

    public void transfer(String senderId, String beneficiaryId, long amount) {
        Account sender = accountManager.findAccountForUser(senderId);
        if (sender == null) {
            throw new IllegalStateException("Sender was not found");
        }
        Account beneficiary = accountManager.findAccountForUser(beneficiaryId);

        sender.withdraw(amount);
        beneficiary.deposit(amount);
        this.accountManager.updateAccount(sender);
        this.accountManager.updateAccount(beneficiary);
    }
}
