package com.luxoft.springadvanced.mockito;

public interface AccountManager {

    Account findAccountForUser(String userId);

}
