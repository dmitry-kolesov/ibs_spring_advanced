package com.luxoft.springadvanced.mockito.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
public class TestWebClientMockito {
    @Mock
    private ConnectionFactory factory;

    @Mock
    private InputStream mockStream;

    @Test
    public void testGetContentOk() throws Exception {
        when(factory.getData()).thenReturn(mockStream);
        String line = readFromFile("test.txt");
        int i = 0;
        when(mockStream.read())
                .thenReturn((int) line.charAt(i++))
                .thenReturn((int) line.charAt(i++))
                .thenReturn((int) line.charAt(i++))
                .thenReturn((int) line.charAt(i++))
                .thenReturn((int) line.charAt(i++))
                .thenReturn((int) line.charAt(i++))
                .thenReturn(-1);

        WebClient client = new WebClient();

        String workingContent = client.getContent(factory);

        verify(mockStream, times(7)).read();

        assertEquals("Spring", workingContent);
    }

    @Test
    public void testGetContentCannotCloseInputStream()
            throws Exception {
        when(factory.getData()).thenReturn(mockStream);
        when(mockStream.read()).thenReturn(-1);
        doThrow(new IOException("cannot close")).when(mockStream).close();

        WebClient client = new WebClient();

        String workingContent = client.getContent(factory);

        verify(mockStream, times(1)).read();

        assertNull(workingContent);
    }

    private String readFromFile(String fileName) {
        try (BufferedReader in =
                     new BufferedReader(
                             new FileReader("src/test/resources/" + fileName))) {
            String line = in.readLine();
            return line;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
