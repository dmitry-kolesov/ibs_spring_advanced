package com.luxoft.springadvanced.database;

import com.luxoft.springadvanced.bank.Account;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.luxoft.springadvanced.database.DatabaseUtil.buildAccountsList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class StatisticsTest {
    @Spy
    private DatabaseStatistics databaseStatistics;

    private List<List<String>> queriedData;
    private List<Account> accountsList;

    @BeforeEach
    void before() {
        queriedData = new ArrayList<>();
        List<String> row1 = Arrays.asList("1", "349");
        List<String> row2 = Arrays.asList("2", "278");
        List<String> row3 = Arrays.asList("3", "319");
        List<String> row4 = Arrays.asList("4", "817");
        List<String> row5 = Arrays.asList("5", "623");
        List<String> row6 = Arrays.asList("6", "978");
        queriedData.add(row1);
        queriedData.add(row2);
        queriedData.add(row3);
        queriedData.add(row4);
        queriedData.add(row5);
        queriedData.add(row6);
    }

    @Test
    void testQueriedData() {
        when(databaseStatistics.queryAccountsDatabase()).thenReturn(queriedData);
        accountsList = buildAccountsList(queriedData);
        assertEquals(6, databaseStatistics.queryAccountsDatabase().size());
        assertEquals(6, accountsList.size());
        assertEquals(560.666, databaseStatistics.averageBalance(accountsList), 0.001);
        assertEquals(278, databaseStatistics.minimumBalance(accountsList));
        assertEquals(978, databaseStatistics.maximumBalance(accountsList));

    }
}
