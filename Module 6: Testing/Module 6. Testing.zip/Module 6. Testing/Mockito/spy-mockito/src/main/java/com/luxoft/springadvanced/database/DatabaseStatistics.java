package com.luxoft.springadvanced.database;


import com.luxoft.springadvanced.bank.Account;

import java.util.ArrayList;
import java.util.List;

public class DatabaseStatistics {

    private List<List<String>> queriedData = new ArrayList<>();

    public List<List<String>> queryAccountsDatabase() {
        return queriedData;
    }

    public double averageBalance(List<Account> accountsList) {
        return //queryAccountsDatabase().stream()
                accountsList.stream()
                .mapToDouble(Account::getBalance)
                .average()
                .getAsDouble();
    }

    public int minimumBalance(List<Account> accountsList) {
        return accountsList.stream()
                .mapToInt(Account::getBalance)
                .min()
                .getAsInt();
    }

    public int maximumBalance(List<Account> accountsList) {
        return accountsList.stream()
                .mapToInt(Account::getBalance)
                .max()
                .getAsInt();
    }
}
