package com.luxoft.springadvanced.bank;

public class Account {
	private String id;
    private int balance;

	public Account(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

}
