package com.luxoft.springadvanced.database;

import com.luxoft.springadvanced.bank.Account;

import java.util.ArrayList;
import java.util.List;

public class DatabaseUtil {

    private DatabaseUtil() {

    }

    public static List<Account> buildAccountsList(List<List<String>> queriedData) {
        List<Account> accountsList = new ArrayList<>();
        for (List<String> row: queriedData) {
            Account account;
            account = new Account(row.get(0));
            account.setBalance(Integer.valueOf(row.get(1)));
            accountsList.add(account);
        }
        return accountsList;
    }
}
