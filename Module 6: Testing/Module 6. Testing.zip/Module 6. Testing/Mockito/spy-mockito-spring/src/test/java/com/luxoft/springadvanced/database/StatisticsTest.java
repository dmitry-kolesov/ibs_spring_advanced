package com.luxoft.springadvanced.database;

import com.luxoft.springadvanced.bank.Account;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.luxoft.springadvanced.database.DatabaseUtil.buildAccountsList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {DatabaseStatisticsTestConfiguration.class})
public class StatisticsTest {
    @Autowired
    private DatabaseStatistics databaseStatistics;

    private List<List<String>> queriedData, firstHalfQueriedData, secondHalfQueriedData;
    private List<Account> accountsList, firstHalfAccountsList, secondHalfAccountsList;

    @BeforeEach
    void before() {
        queriedData = new ArrayList<>();
        firstHalfQueriedData = new ArrayList<>();
        secondHalfQueriedData = new ArrayList<>();
        List<String> row1 = Arrays.asList("1", "349");
        List<String> row2 = Arrays.asList("2", "278");
        List<String> row3 = Arrays.asList("3", "319");
        List<String> row4 = Arrays.asList("4", "817");
        List<String> row5 = Arrays.asList("5", "623");
        List<String> row6 = Arrays.asList("6", "978");
        queriedData.add(row1);
        queriedData.add(row2);
        queriedData.add(row3);
        queriedData.add(row4);
        queriedData.add(row5);
        queriedData.add(row6);
        firstHalfQueriedData.add(row1);
        firstHalfQueriedData.add(row2);
        firstHalfQueriedData.add(row3);
        secondHalfQueriedData.add(row4);
        secondHalfQueriedData.add(row5);
        secondHalfQueriedData.add(row6);
    }



    @Test
    void testQueriedData() {
        when(databaseStatistics.queryAccountsDatabase()).thenReturn(queriedData);
        firstHalfAccountsList = buildAccountsList(firstHalfQueriedData);
        checkFirstHalfQueriedData();

        secondHalfAccountsList = buildAccountsList(secondHalfQueriedData);
        checkSecondHalfQueriedData();

        accountsList = buildAccountsList(queriedData);
        checkQueriedData();

        verify(databaseStatistics, times(3)).queryAccountsDatabase();
        verify(databaseStatistics, times(3)).averageBalance(any());
        verify(databaseStatistics, times(3)).minimumBalance(any());
        verify(databaseStatistics, times(3)).maximumBalance(any());

    }

    private void checkFirstHalfQueriedData() {
        assertEquals(6, databaseStatistics.queryAccountsDatabase().size());
        assertEquals(3, firstHalfAccountsList.size());
        assertEquals(315.333, databaseStatistics.averageBalance(firstHalfAccountsList), 0.001);
        assertEquals(278, databaseStatistics.minimumBalance(firstHalfAccountsList));
        assertEquals(349, databaseStatistics.maximumBalance(firstHalfAccountsList));
    }

    private void checkSecondHalfQueriedData() {
        assertEquals(6, databaseStatistics.queryAccountsDatabase().size());
        assertEquals(3, secondHalfAccountsList.size());
        assertEquals(806.0, databaseStatistics.averageBalance(secondHalfAccountsList), 0.001);
        assertEquals(623, databaseStatistics.minimumBalance(secondHalfAccountsList));
        assertEquals(978, databaseStatistics.maximumBalance(secondHalfAccountsList));
    }

    private void checkQueriedData() {
        assertEquals(6, databaseStatistics.queryAccountsDatabase().size());
        assertEquals(6, accountsList.size());
        assertEquals(560.666, databaseStatistics.averageBalance(accountsList), 0.001);
        assertEquals(278, databaseStatistics.minimumBalance(accountsList));
        assertEquals(978, databaseStatistics.maximumBalance(accountsList));
    }
}
