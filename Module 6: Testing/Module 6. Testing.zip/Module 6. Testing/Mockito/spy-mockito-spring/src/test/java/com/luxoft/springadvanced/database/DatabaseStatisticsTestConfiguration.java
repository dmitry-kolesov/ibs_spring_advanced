package com.luxoft.springadvanced.database;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DatabaseStatisticsTestConfiguration {
    @Bean
    public DatabaseStatistics getDatabaseStatistics() {
        return Mockito.spy(DatabaseStatistics.class);
    }
}
