package com.luxoft.springadvanced.services;

public interface Job {
	String getDescription();
}
