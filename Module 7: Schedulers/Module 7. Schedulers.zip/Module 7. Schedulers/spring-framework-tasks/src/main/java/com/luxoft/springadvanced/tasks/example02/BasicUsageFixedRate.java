package com.luxoft.springadvanced.tasks.example02;

import org.springframework.scheduling.annotation.Scheduled;

import java.util.Date;

public class BasicUsageFixedRate {

    @Scheduled(fixedDelay = 3000)
    public void execute() throws Exception {
        System.out.println("Executed every 3 seconds. Current time: " + new Date());
        Thread.sleep(7000);
    }

    @Scheduled(fixedDelayString = "#{T(java.util.concurrent.TimeUnit).MINUTES.toMillis(${job.new_run_delay_minutes})}")
    public void executeWithMinutesDelay() {
        System.out.println("Executed after configured timeout in minutes. Current time: " + new Date());
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
