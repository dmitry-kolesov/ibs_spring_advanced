package com.luxoft.springadvanced.tasks.example03;

import java.util.Date;

public class CronUsageRateXml {
    public void execute() {
        System.out.println("Executed at 10:15 AM on the 15th day of every month. Current time: " + new Date());
    }

}
