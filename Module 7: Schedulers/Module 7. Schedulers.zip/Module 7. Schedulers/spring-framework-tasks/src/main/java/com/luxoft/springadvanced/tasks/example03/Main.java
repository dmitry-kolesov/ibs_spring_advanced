package com.luxoft.springadvanced.tasks.example03;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		new ClassPathXmlApplicationContext("example03/application-context.xml");
	}
}
