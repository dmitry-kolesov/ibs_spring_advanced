package com.luxoft.springadvanced.tasks.example02;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		new ClassPathXmlApplicationContext("example02/application-context.xml");
	}
}
